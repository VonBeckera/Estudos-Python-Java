package empresa_davi;

public class Principal {

	public static void main(String[] args) {
		Nota aluno = new Nota();
		Aluno Aluno = new Aluno();
		//aluno.receberNotas();
		//aluno.calcularMedia();
		//aluno.recebeFaltas();
		//aluno.resultado();
		Curso curso = new Curso();
		Aluno.pegarDados();
		Aluno.pagamentoCurso();
		Aluno.mostrarDados();
		Aluno.curso.InfoCurso();
		
		

	}

}
