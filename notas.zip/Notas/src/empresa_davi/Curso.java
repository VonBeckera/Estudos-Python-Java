package empresa_davi;

public class Curso {
	public String nomeCurso;
	public double valorCurso;
	
	public void InfoCurso() {
		System.out.println("Nome do curso: " + nomeCurso);
	    System.out.println("Valor do curso: R$ " + valorCurso);

	}

	public String getNomeCurso() {
		return nomeCurso;
	}

	public void setNomeCurso(String nomeCurso) {
		this.nomeCurso = nomeCurso;
	}

	public double getValorCurso() {
		return valorCurso;
	}

	public void setValorCurso(double valorCurso) {
		this.valorCurso = valorCurso;
	}

}
