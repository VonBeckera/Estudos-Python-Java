package empresa_davi;
import java.util.ArrayList;
import java.util.Scanner;
public class Aluno {
	private String nome;
	private String matricula;
	private String cpf;
	private double desconto;
	private Scanner reader = new Scanner(System.in);
	private ArrayList<String> listaDeArrays = new ArrayList<>();
	public int faltas;
	Curso curso = new Curso();
	/**
	 * @return the nome
	 */
	public String getNome() {
		return nome;
	}
	/**
	 * @param nome the nome to set
	 */
	public void setNome(String nome) {
		this.nome = nome;
	}
	/**
	 * @return the cpf
	 */
	public String getCpf() {
		return cpf;
	}
	/**
	 * @param cpf the cpf to set
	 */
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	/**
	 * @return the matricula
	 */
	public String getMatricula() {
		return matricula;
	}
	/**
	 * @param matricula the matricula to set
	 */
	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}
	
	void pegarDados() {
		
		while (true){
			System.out.println("Deseja cadastrar um aluno? [S/N]: ");
			String op = reader.next();
			
			if (op.equalsIgnoreCase("S")) {
				
				System.out.println("Digite o Nome do Aluno: ");
		        nome = reader.next();
		
		        System.out.println("Digite a matrícula do Aluno: ");
		        matricula = reader.next();
		
		        System.out.println("Digite o CPF do Aluno: ");
		        cpf = reader.next();
		       
		        System.out.println("Digite o Curso do Aluno: ");
		        curso.nomeCurso = reader.next();
		       
		        System.out.println("Digite o desconto do Aluno: ");
		        desconto = reader.nextDouble();
		       
		        System.out.println("Digite o valor do curso do Aluno: ");
		        curso.valorCurso = reader.nextDouble();
		       
			}else if(op.equalsIgnoreCase("N")) {
				System.out.println("Saindo do Programa\n");
				break;
				
			}else {
				System.out.println("Opção inválida tente novamente");
				continue;
			}
			continue;
		}
	}
	
	 void mostrarDados() {
		System.out.println("ALUNO CADASTRADO \n");
		System.out.println("Nome: " +nome );
		System.out.println("CPF: " + cpf);
	    System.out.println("Matricula: " +matricula);
	    System.out.println("Curso: " +curso.getNomeCurso());
	    System.out.println("Desconto de " +desconto+"%");
	    System.out.println("Valor da Mensalidade com desconto é de :"+"R$"+pagamentoCurso()+"\n"+"Valor do curso sem desconto é R$ "+curso.getValorCurso());
	    
	}
	 
	 public double pagamentoCurso() {
		 double valorComDesconto = curso.getValorCurso() - (curso.getValorCurso() * desconto / 100);
		    return valorComDesconto;
	 }
	
	/**
	 * @return the desconto
	 */
	public double getDesconto() {
		return desconto;
	}
	/**
	 * @param desconto the desconto to set
	 */
	public void setDesconto(double desconto) {
		this.desconto = desconto;
	}
	

}
