package empresa_davi;
import java.util.Scanner;
public class Nota {
	private double nota1;
	private double nota2;
	private double media;
	private Scanner scanner = new Scanner(System.in);
	private int faltas = 0;
	
	public Nota() {
	}
	
	public Nota(double nota1, double nota2, double media, Scanner scanner, int faltas) {
		setNota1(nota1);
		setNota2(nota2);
		this.media = media;
		this.scanner = scanner;
		setFaltas(faltas);
	}
	/**
	 * @return the nota1
	 */
	public double getNota1() {
		return nota1;
	}
	/**
	 * @param nota1 the nota1 to set
	 */
	public void setNota1(double nota1) {
		if(nota1 <0 || nota1 >10) {
			System.out.println("Nota Inválida");
			return;
		}
		this.nota1 = nota1;	
	}
	/**
	 * @return the nota2
	 */
	public double getNota2() {
		return nota2;
	}
	/**
	 * @param nota2 the nota2 to set
	 */
	public void setNota2(double nota2) {
		if(nota2 <0 || nota2 >10) {
			System.out.println("Nota Inválida");
			return;
		}
		this.nota2 = nota2;
		
	}
	
	/**
	 * @return the faltas
	 */
	public int getFaltas() {
		return faltas;
	}
	/**
	 * @param faltas the faltas to set
	 */
	public void setFaltas(int faltas) {
		if(faltas > 40 || faltas < 0) {
			System.out.println("Número de faltas inválidas!");
			return;
		}
		this.faltas = faltas;
		
	}
	
	void resultado() {
		  if(faltas > 7){
			   System.out.println("Reprovado por ter " +faltas+" faltas " +  "com media: "+media);
			   
		  }else if (media >= 7 ){
        	  System.out.println("A Aprovado com média: "+media);
        	  
		   }else if (media >= 5 && media < 7) {
			   System.out.println("Aluno em recuperação, media: "+media);
			   
		   }else {
			   System.out.println("Aluno reprovado com media: " +media+ " e com " +faltas+ " Faltas");
		   }
	    
	}
	
	double calcularMedia() {
		media = ((nota1+nota2) / 2);
		return media;
	}
	
	void receberNotas() {
		System.out.println("Digite a Primeira nota: ");
		nota1 = scanner.nextDouble();
		
		System.out.println("Digite a Segunda nota: ");
		nota2 = scanner.nextDouble();
	}
	void recebeFaltas() {
		System.out.println("Digite as faltas do aluno: ");
		faltas = scanner.nextInt();
		
	}

}
